import 'package:flutter/material.dart';

class Notifications extends StatefulWidget {

  @override
  State<Notifications> createState() => _NotificationsState();
}

class _NotificationsState extends State<Notifications> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.grey[900]

    );
  }
}
