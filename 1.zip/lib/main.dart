
import 'package:flutter/material.dart';
import 'package:reddit2/welcomepage.dart';

void main() {
  runApp(MaterialApp(home: welcomePage()));

}

